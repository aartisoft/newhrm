<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Budget_revenues extends MX_Controller {

	function __construct()
	{
		parent::__construct();
		User::logged_in();

		$this->load->module('layouts');	
		$this->load->library(array('template','form_validation'));
		$this->template->title('budget_revenues');
		$this->load->model(array('App'));

		$this->applib->set_locale();
		$this->load->helper('date');
	}

	function index()
	{
		$this->load->module('layouts');

		$this->load->library('template');		 

		$this->template->title(lang('budget_revenues').' - '.config_item('company_name'));
		$data['page'] = lang('budget_revenues');
		$data['datatables'] = TRUE;
		$data['form'] = TRUE;
		 $this->session->unset_userdata('budget_title');
		 $this->session->unset_userdata('budget_start_date');
		 $this->session->unset_userdata('budget_end_date');

		//print_r($_POST); exit;
		$data['budget_re'] = $this->db->get('budgets')->result_array();
		if($_POST){
				
			
				$this->session->unset_userdata('budget_title');
				$this->session->unset_userdata('budget_start_date');
				$this->session->unset_userdata('budget_end_date');
				
				
				if($_POST['budget_title']!= ''){
					$this->session->unset_userdata('budget_title');
					$this->session->set_userdata('budget_title',$_POST['budget_title']);
					$this->db->where('budget_title',$_POST['budget_title']);
				}
				if($_POST['budget_start_date']!= ''){
					$this->session->unset_userdata('budget_start_date');
					$this->session->set_userdata('budget_start_date',$_POST['budget_start_date']);
					$start_date = date("Y-m-d", strtotime($_POST['budget_start_date']));
					$this->db->where('budget_start_date >=', $start_date);
				}
				if($_POST['budget_end_date']!= ''){
					$this->session->unset_userdata('budget_end_date');
					$this->session->set_userdata('budget_end_date',$_POST['budget_end_date']);
					$to_date = date("Y-m-d", strtotime($_POST['budget_end_date']));
					$this->db->where('budget_end_date <=', $to_date);
				}
			//	return $this->db->get()->result_array();
			

				$data['budgets'] = $this->db->get('budgets')->result_array();
					
		} else {

				$data['budgets'] = $this->db->get('budgets')->result_array();
				

		}
		
		$data['projects'] = $this->db->get('projects')->result_array();
		$data['budget_category'] = $this->db->get('budget_category')->result_array();
		//ECHO '<pre>'; print_r($data['budgets']); EXIT;
		$this->template

			 ->set_layout('users')

			 ->build('budget_revenues',isset($data) ? $data : NULL);
	}


		
}

/* End of file Social_impact.php */