<div class="content container-fluid">
          <div class="row">
            <div class="col-xs-8">
              <h4 class="page-title">Income Statement</h4>
            </div>
          </div>
          <div class="card-box">
                    <h4 class="card-title">Income Statement</h4>
                    <div class="table-responsive border">
                      <table class="table table-hover accounts-table mb-0">
                        <thead>
                          <th></th>
                          <?php foreach($years as $year) {?>
                          <th><?php echo $year; ?></th>
                         <?php } ?>
                        </thead>
                        <tbody>
                          <tr>
                            <td><strong>Revenue</strong></td>
                             <?php foreach($revenue as $revenues) {?>
                               <td><strong><?php echo !empty($revenues)?$revenues:'-'; ?></strong></td>
                         <?php } ?>
                          </tr>
                             <?php 
                              $start_years = Date('Y', strtotime("-8 Year"));
                              $current_year = date("Y");

                              for ($i=$start_years; $i <=$current_year ; $i++) { 
                               
                              
                            if(!empty($profit[$i])) {
                               foreach($profit[$i] as $profits) {
                                    // $revenue_title = json_decode($profits['revenue_title']);
                                    // $revenue_title = implode(',', $revenue_title);
                                ?>
                                  <tr>
                            
                               <td><?php echo $profits['revenue_title']; ?></td>

                               <?php
$payment_amount='-';
                               for ($j=$start_years; $j <=$current_year ; $j++) { 
      
                                    $years[]= $j;
                                    $end_year = $j+1;
                                      $financial_start_date = $i.'-04-1';
                                      $financial_end_date = $end_year.'-03-31';
                                      $this->db->select('amount');
                                      $this->db->where('p_id', $profits['payment_id']);
                                    $this->db->where('payment_date >=', $financial_start_date);
                                    $this->db->where('payment_date <=', $financial_end_date);
                                    $payment_amount = $this->db->get('payments')->row()->amount;

                                    ?>
                               <td><strong><?php echo  !empty($payment_amount)?$payment_amount:'-'; ?></strong></td>
                             <?php } ?>
                        
                           </tr>      
                           <?php    }
                              }
                                                
                           } ?>
                          <tr>
                            <td><strong>Gross Profit</strong></td>
                            <?php foreach($gross_profit as $gross_profits) {?>
                               <td><strong><?php echo !empty($gross_profits)?$gross_profits:'-'; ?></strong></td>
                         <?php } ?>
                          </tr>
                          <tr>
                            <td colspan="10"><strong>Expenses</strong></td>
                          </tr>
                           <?php 
                              $start_years = Date('Y', strtotime("-8 Year"));
                              $current_year = date("Y");

                              for ($i=$start_years; $i <=$current_year ; $i++) { 
                               
                              
                            if(!empty($expenses[$i])) {
                               foreach($expenses[$i] as $expense) {
                                    // $expenses_title = json_decode($expense['expenses_title']);
                                    // $expenses_title = implode(',', $expenses_title);
                                ?>
                                  <tr>
                            
                               <td><?php echo $expense['expenses_title'].'('.$expense['notes'].')'; ?></td>

                               <?php
                               for ($j=$start_years; $j <=$current_year ; $j++) { 
      
                                    $years[]= $j;
                                    $end_year = $j+1;
                                      $financial_start_date = $i.'-04-1';
                                      $financial_end_date = $end_year.'-03-31';
                                      $this->db->select('amount');
                                      $this->db->where('id', $expense['id']);
                                    $this->db->where('expense_date >=', $financial_start_date);
                                    $this->db->where('expense_date <=', $financial_end_date);
                                    $expenses = $this->db->get('expenses')->row()->amount;

                                    ?>
                               <td><strong><?php echo  !empty($expenses)?$expenses:'-'; ?></strong></td>
                             <?php } ?>
                        
                           </tr>      
                           <?php    }
                              }
                                                
                           } ?>
                          <tr class="total-row">
                            <td><strong>Total Expenses</strong></td>
                            <?php foreach($overall_expenses as $overall_expense) {?>
                               <td><strong><?php echo !empty($overall_expense)?$overall_expense:'-'; ?></strong></td>
                         <?php } ?>
                          </tr>
                         <!--  <tr>
                            <td><strong>Earnings Before Tax</strong></td>
                            <td><strong>3,594</strong></td>
                            <td><strong>16,649</strong></td>
                            <td><strong>29,558</strong></td>
                            <td><strong>37,622</strong></td>
                            <td><strong>39,825</strong></td>
                            <td><strong>48,827</strong></td>
                            <td><strong>53,319</strong></td>
                            <td><strong>61,210</strong></td>
                          </tr> -->
                          <tr>
                            <td>Taxes</td>
                            <?php foreach($tax_amount as $tax_amounts) {?>
                               <td><strong><?php echo !empty($tax_amounts)?$tax_amounts:'-'; ?></strong></td>
                         <?php } ?>
                          </tr>
                          <tr class="total-row">
                            <td><strong>Net Earnings</strong></td>
                             <?php foreach($net_earnig as $net_earnigs) {?>
                               <td><strong><?php echo !empty($net_earnigs)?$net_earnigs:'-'; ?></strong></td>
                         <?php } ?>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>    
</div>

                