<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class budget_statement extends MX_Controller {

	function __construct()
	{
		parent::__construct();
		User::logged_in();

		$this->load->module('layouts');	
		$this->load->library(array('template','form_validation'));
		$this->template->title('budget_statement');
		$this->load->model(array('App'));

		$this->applib->set_locale();
		$this->load->helper('date');
	}

	function index()
	{
		$this->load->module('layouts');

		$this->load->library('template');		 

		$this->template->title(lang('budget_statement').' - '.config_item('company_name'));
		$data['page'] = lang('budget_statement');
		$data['datatables'] = TRUE;
		$data['form'] = TRUE; 	
		$start_years = Date('Y', strtotime("-8 Year"));
		$current_year = date("Y");

		for ($i=$start_years; $i <=$current_year ; $i++) { 
			
			$years[]= $i;
			$end_year = $i+1;
				$financial_start_date = $i.'-4-1';
				$financial_end_date = $end_year.'-3-31';
			$this->db->select('sum(overall_revenues) as revenue');
			$this->db->where('budget_start_date >=', $financial_start_date);
			$this->db->where('budget_end_date <=', $financial_end_date);
			$revenue[] = $this->db->get('budgets')->row()->revenue;

			$this->db->select('revenue_title,budget_id');
			$this->db->where('budget_start_date >=', $financial_start_date);
			$this->db->where('budget_end_date <=', $financial_end_date);
			$profit[$i] = $this->db->get('budgets')->result_array();

			$this->db->select('sum(expected_profit) as gross_profit');
			$this->db->where('budget_start_date >=', $financial_start_date);
			$this->db->where('budget_end_date <=', $financial_end_date);
			$gross_profit[] = $this->db->get('budgets')->row()->gross_profit;

			$this->db->select('expenses_title,budget_id');
			$this->db->where('budget_start_date >=', $financial_start_date);
			$this->db->where('budget_end_date <=', $financial_end_date);
			$expenses[$i] = $this->db->get('budgets')->result_array();

			$this->db->select('sum(overall_expenses) as overall_expenses');
			$this->db->where('budget_start_date >=', $financial_start_date);
			$this->db->where('budget_end_date <=', $financial_end_date);
			$overall_expenses[] = $this->db->get('budgets')->row()->overall_expenses;

			$this->db->select('sum(tax_amount) as tax_amount');
			$this->db->where('budget_start_date >=', $financial_start_date);
			$this->db->where('budget_end_date <=', $financial_end_date);
			$tax_amount[] = $this->db->get('budgets')->row()->tax_amount;

			$this->db->select('sum(budget_amount) as budget_amount');
			$this->db->where('budget_start_date >=', $financial_start_date);
			$this->db->where('budget_end_date <=', $financial_end_date);
			$net_earnig[] = $this->db->get('budgets')->row()->budget_amount;

		}
		$data['years'] = $years;
		$data['revenue'] = $revenue;
		$data['profit'] = $profit;
		$data['gross_profit'] = $gross_profit;
		$data['expenses'] = $expenses;
		$data['overall_expenses'] = $overall_expenses;
		$data['tax_amount'] = $tax_amount;
		$data['net_earnig'] = $net_earnig;
;
		//echo '<pre>';print_r($data['profit']);exit;
		//print_r($this->db->last_query());
		
					
		
		$this->template

			 ->set_layout('users')

			 ->build('budget_statement',isset($data) ? $data : NULL);
	}

	
}

/* End of file Social_impact.php */